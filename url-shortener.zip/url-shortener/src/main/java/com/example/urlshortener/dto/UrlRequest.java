package com.example.urlshortener.dto;

import java.time.LocalDateTime;

public class UrlRequest {
    private String longUrl;
    private String customAlias;
    private LocalDateTime expiryDate;

    // Getters and Setters
    // ...
}
